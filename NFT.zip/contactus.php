<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <!-- 
    - primary meta tags
  -->
  <title>Nestostorm- Trusted & Secure Trading Nft website</title>
  <meta name="title" content="Nestostorm- Trusted & Secure Trading Nft website">
  <meta name="description" >

  <!-- 
    - favicon
  -->

  <!-- 
    - custom css link
  -->
  <link rel="stylesheet" href="Auction.css">

  <!-- 
    - google font link
  -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link
    href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;500;600;700&family=Poppins:wght@400;500;600;700;800&display=swap"
    rel="stylesheet">

  <!-- 
    - preload images
  -->
  <link rel="preload" as="image" href="./assets/images/hero-banner.png">

</head>

<body>

  <!-- 
    - #HEADER
  -->

  <header class="header" data-header>
    <div class="container">

      <a href="#" class="logo">
        <img src="assets/images/logo.png" width="100" height="100" alt=" home">
      </a>

      <nav class="navbar" data-navbar>

        <div class="navbar-top">

          <a href="#" class="logo">
            <img src="./assets/images/logo.svg" width="185" height="31" alt="home">
          </a>

          <button class="nav-close-btn" aria-label="close menu" data-nav-toggler>
            <ion-icon name="close-outline" aria-hidden="true"></ion-icon>
          </button>

        </div>

        <ul class="navbar-list">

          <li>
            <a href="user_index.php" class="navbar-link">Home</a>
          </li>

          <li>
            <a href="auction.php" class="navbar-link">Explore</a>
          </li>


          <li>
            <a href="Topseller.php" class="navbar-link">TopSeller</a>
          </li>

          <li>
            <a href="contactus.php" class="navbar-link">Contact</a>
          </li>

        </ul>

      </nav>

      <div class="btn-group">
        <a href="dl.php" class="btn ghost-btn">Sign In</a>
        
        <a href="wallet.html" class="btn btn-primary" style="width: 300px;"><ion-icon name="wallet-outline"></ion-icon>
          Wallet</a>
      </div>

      <button class="nav-open-btn" aria-label="open menu" data-nav-toggler>
        <ion-icon name="menu-outline" aria-hidden="true"></ion-icon>
      </button>

      <div class="overlay" data-overlay data-nav-toggler></div>

    </div>
  </header>

 

  <div class="container">
    <ul class="breadcrumb">
      <li><a href="index.html">Home</a> <span class="divider">/</span></li>
      <li class="active">Contact</li>
  </ul>
</div>

<div style="-webkit-filter: grayscale(100%); filter: grayscale(100%);">
  <iframe width="100%;" height="400" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" style="pointer-events: none;" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2483.281992959266!2d-0.1302576842043993!3d51.5080423184772!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x487604ce3941eb1f%3A0x1a5342fdf089c627!2sTrafalgar+Square!5e0!3m2!1sen!2suk!4v1462913556349"></iframe>
</div>

<div class="contact">
  <div class="container">
    <div class="col-md-8">
      <div class="contact-form">
        <h3>Contact Form</h3>
        <hr>
        <form action="#" method="post">
          <h2>Name:</h2><input id="name" name="name" type="text" placeholder="Name" required>
          <h2>E-mail:</h2><input id="email" name="email" type="text" placeholder="Email" required>
          <h2>Subject:</h2><input id="subject" name="subject" type="text" placeholder="Subject" required>
          <textarea id="message" name="message" placeholder="Your Message" rows="5" required></textarea>
          <button name="submit" id="submit" type="submit">Send Message</button>
        </form>
      </div>
    </div>
    <div class="col-md-4">
      <div class="contact-info">
        <h3>Contact Info</h3>
        <hr>
        <p>Lorem ipsum dolor sit amet, vim et doctus suavitate iracundia, vix mediocrem quaerendum in. Quis paulo facilis mei ut, feugait persecuti eu mel. Sit ut illud quaestio sadipscing, sed noster intellegam ne.</p>
        <p><strong>Address:</strong> Trafalgar Square, Westminister WC2N 5DN</p>
        <p><strong>Mail:</strong> company@domain.com</p>
        <p><strong>Phone:</strong> +44 0799 6789 1234</p>
        <p><strong>Fax:</strong> +44 1234 22 9876</p>
      </div>
    </div>
  </div>
</div>


<footer class="footer">

  <div class="footer-top section">
    <div class="container">

      <div class="footer-brand">

        <a href="#" class="logo">
          <img src="assets/images/logo.png" width="50" height="50" alt=" home">
        </a>

        

      </div>

</footer>



  <!-- 
    - custom js link
  -->
  <script src="./assets/js/script.js" defer></script>

  <!-- 
    - ionicon-link
  -->
  <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
  <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>



</body>

</html>