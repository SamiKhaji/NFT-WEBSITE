<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <!-- 
    - primary meta tags
  -->
  <title>Nestostorm- Trusted & Secure Trading Nft website</title>
  <meta name="title" content="Nestostorm- Trusted & Secure Trading Nft website">
  <meta name="description" >

  <!-- 
    - favicon
  -->

  <!-- 
    - custom css link
  -->
  <link rel="stylesheet" href="Auction.css">

  <!-- 
    - google font link
  -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link
    href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;500;600;700&family=Poppins:wght@400;500;600;700;800&display=swap"
    rel="stylesheet">

  <!-- 
    - preload images
  -->
  <link rel="preload" as="image" href="./assets/images/hero-banner.png">

</head>

<body>

  <!-- 
    - #HEADER
  -->

  <header class="header" data-header>
    <div class="container">

      <a href="#" class="logo">
        <img src="assets/images/logo.png" width="100" height="100" alt=" home">
      </a>

      <nav class="navbar" data-navbar>

        <div class="navbar-top">

          <a href="#" class="logo">
            <img src="./assets/images/logo.svg" width="185" height="31" alt="home">
          </a>

          <button class="nav-close-btn" aria-label="close menu" data-nav-toggler>
            <ion-icon name="close-outline" aria-hidden="true"></ion-icon>
          </button>

        </div>

        <ul class="navbar-list">

          <li>
            <a href="index.php" class="navbar-link">Home</a>
          </li>

          <li>
            <a href="auction1.php" class="navbar-link">Explore</a>
          </li>
          <li>
            <a href="collection.php" class="navbar-link">Collection</a>
          </li>

         

          <li>
            <a href="Topseller1.php" class="navbar-link">TopSeller</a>
          </li>

          <li>
            <a href="contactus1.php" class="navbar-link">Contact</a>
          </li>

        </ul>

      </nav>

      <div class="btn-group">
        <a href="profile.php"><ion-icon name="menu-outline" aria-hidden="true"></ion-icon></a>
        
        <a href="wallet1.html" class="btn btn-primary" style="width: 300px;"><ion-icon name="wallet-outline"></ion-icon>
          Wallet</a>
      </div>

      <button class="nav-open-btn" aria-label="open menu" data-nav-toggler>
        <ion-icon name="menu-outline" aria-hidden="true"></ion-icon>
      </button>

      <div class="overlay" data-overlay data-nav-toggler></div>

    </div>
  </header>

  
      <section class="section explore" id="explore">
        <div class="container">

          <p class="section-subtitle">Exclusive Assets</p>

          <div class="title-wrapper">
            <h2 class="h2 section-title">Explore</h2>

            <a href="#" class="btn-link">
              <span>Explore All</span>

              <ion-icon name="arrow-forward-outline" aria-hidden="true"></ion-icon>
            </a>
          </div>

          <ul class="grid-list">

            <li>
              <div class="card explore-card">

                <figure class="card-banner">
                  <a href="#">
                    <img src="./assets/images/auction-1.jpg" width="600" height="600" loading="lazy"
                      alt="Walking On Air" class="img-cover">
                  </a>
                </figure>

                <h3 class="h3 card-title">
                  <a href="#">Walking On Air</a>
                </h3>

                <span class="card-author">
                  Owned By <a href="#" class="author-link">Richard</a>
                </span>

                <div class="wrapper">
                  <data class="wrapper-item" value="1.5">1.5 ETH</data>

                  <span class="wrapper-item">1 of 1</span>
                </div>

                <button class="btn">
                  <ion-icon name="bag-add-outline" aria-hidden="true"></ion-icon>

                  <a href="placeabid.html"><span>Place a Bid</span></a>
                </button>

              </div>
            </li>

            <li>
              <div class="card explore-card">

                <figure class="card-banner">
                  <a href="#">
                    <img src="./assets/images/auction-2.jpg" width="600" height="600" loading="lazy" alt="Domain Names"
                      class="img-cover">
                  </a>
                </figure>

                <h3 class="h3 card-title">
                  <a href="#">Domain Names</a>
                </h3>

                <span class="card-author">
                  Owned By <a href="#" class="author-link">John Deo</a>
                </span>

                <div class="wrapper">
                  <data class="wrapper-item" value="2.7">2.7 ETH</data>

                  <span class="wrapper-item">1 of 1</span>
                </div>

                <button class="btn">
                  <ion-icon name="bag-add-outline" aria-hidden="true"></ion-icon>

                  <a href="placeabid.html"><span>Place a Bid</span></a>
                </button>

              </div>
            </li>

            <li>
              <div class="card explore-card">

                <figure class="card-banner">
                  <a href="#">
                    <img src="./assets/images/auction-3.jpg" width="600" height="600" loading="lazy" alt="Trading Cards"
                      class="img-cover">
                  </a>
                </figure>

                <h3 class="h3 card-title">
                  <a href="#">Trading Cards</a>
                </h3>

                <span class="card-author">
                  Owned By <a href="#" class="author-link">Arham</a>
                </span>

                <div class="wrapper">
                  <data class="wrapper-item" value="2.3">2.3 ETH</data>

                  <span class="wrapper-item">1 of 1</span>
                </div>

                <button class="btn">
                  <ion-icon name="bag-add-outline" aria-hidden="true"></ion-icon>

                  <a href="placeabid.html"><span>Place a Bid</span></a>
                </button>

              </div>
            </li>

            <li>
              <div class="card explore-card">

                <figure class="card-banner">
                  <a href="#">
                    <img src="./assets/images/auction-4.jpg" width="600" height="600" loading="lazy"
                      alt="Industrial Revolution" class="img-cover">
                  </a>
                </figure>

                <h3 class="h3 card-title">
                  <a href="#">Industrial Revolution</a>
                </h3>

                <span class="card-author">
                  Owned By <a href="#" class="author-link">Yasmin</a>
                </span>

                <div class="wrapper">
                  <data class="wrapper-item" value="1.8">1.8 ETH</data>

                  <span class="wrapper-item">1 of 1</span>
                </div>

                <button class="btn">
                  <ion-icon name="bag-add-outline" aria-hidden="true"></ion-icon>

                  <a href="placeabid.html"><span>Place a Bid</span></a>
                </button>

              </div>
            </li>

            <li>
              <div class="card explore-card">

                <figure class="card-banner">
                  <a href="#">
                    <img src="./assets/images/auction-5.jpg" width="600" height="600" loading="lazy" alt="Utility"
                      class="img-cover">
                  </a>
                </figure>

                <h3 class="h3 card-title">
                  <a href="#">Utility</a>
                </h3>

                <span class="card-author">
                  Owned By <a href="#" class="author-link">Junaid</a>
                </span>

                <div class="wrapper">
                  <data class="wrapper-item" value="1.7">1.7 ETH</data>

                  <span class="wrapper-item">1 of 1</span>
                </div>

                <button class="btn">
                  <ion-icon name="bag-add-outline" aria-hidden="true"></ion-icon>

                  <a href="placeabid.html"><span>Place a Bid</span></a>
                </button>

              </div>
            </li>

            <li>
              <div class="card explore-card">

                <figure class="card-banner">
                  <a href="#">
                    <img src="./assets/images/auction-6.jpg" width="600" height="600" loading="lazy" alt="Sports"
                      class="img-cover">
                  </a>
                </figure>

                <h3 class="h3 card-title">
                  <a href="#">Sports</a>
                </h3>

                <span class="card-author">
                  Owned By <a href="#" class="author-link">ArtNox</a>
                </span>

                <div class="wrapper">
                  <data class="wrapper-item" value="1.7">1.7 ETH</data>

                  <span class="wrapper-item">1 of 1</span>
                </div>

                <button class="btn">
                  <ion-icon name="bag-add-outline" aria-hidden="true"></ion-icon>

                  <a href="placeabid.html"><span>Place a Bid</span></a>
                </button>

              </div>
            </li>

            <li>
              <div class="card explore-card">

                <figure class="card-banner">
                  <a href="#">
                    <img src="./assets/images/auction-7.jpg" width="600" height="600" loading="lazy"
                      alt="Cartoon Heroes" class="img-cover">
                  </a>
                </figure>

                <h3 class="h3 card-title">
                  <a href="#">Cartoon Heroes</a>
                </h3>

                <span class="card-author">
                  Owned By <a href="#" class="author-link">Junaid</a>
                </span>

                <div class="wrapper">
                  <data class="wrapper-item" value="3.2">3.2 ETH</data>

                  <span class="wrapper-item">1 of 1</span>
                </div>

                <button class="btn">
                  <ion-icon name="bag-add-outline" aria-hidden="true"></ion-icon>

                  <a href="placeabid.html"><span>Place a Bid</span></a>
                </button>

              </div>
            </li>

            <li>
              <div class="card explore-card">

                <figure class="card-banner">
                  <a href="#">
                    <img src="./assets/images/auction-8.jpg" width="600" height="600" loading="lazy" alt="Gaming Chair"
                      class="img-cover">
                  </a>
                </figure>

                <h3 class="h3 card-title">
                  <a href="#">Gaming Chair</a>
                </h3>

                <span class="card-author">
                  Owned By <a href="#" class="author-link">Johnson</a>
                </span>

                <div class="wrapper">
                  <data class="wrapper-item" value="0.69">0.69 ETH</data>

                  <span class="wrapper-item">1 of 1</span>
                </div>

                <button class="btn">
                  <ion-icon name="bag-add-outline" aria-hidden="true"></ion-icon>

                  <a href="placeabid.html"><span>Place a Bid</span></a>
                </button>

              </div>
            </li>

            <li>
              <div class="card explore-card">

                <figure class="card-banner">
                  <a href="#">
                    <img src="./assets/images/auction-9.jpg" width="600" height="600" loading="lazy" alt="Utility"
                      class="img-cover">
                  </a>
                </figure>

                <h3 class="h3 card-title">
                  <a href="#">Utility</a>
                </h3>

                <span class="card-author">
                  Owned By <a href="#" class="author-link">Junaid</a>
                </span>

                <div class="wrapper">
                  <data class="wrapper-item" value="1.7">1.7 ETH</data>

                  <span class="wrapper-item">1 of 1</span>
                </div>

                <button class="btn">
                  <ion-icon name="bag-add-outline" aria-hidden="true"></ion-icon>

                  <a href="placeabid.html"><span>Place a Bid</span></a>
                </button>

              </div>
            </li>

            <li>
              <div class="card explore-card">

                <figure class="card-banner">
                  <a href="#">
                    <img src="auction10.jpg" width="600" height="600" loading="lazy" alt="Sports"
                      class="img-cover">
                  </a>
                </figure>

                <h3 class="h3 card-title">
                  <a href="#">Sports</a>
                </h3>

                <span class="card-author">
                  Owned By <a href="#" class="author-link">ArtNox</a>
                </span>

                <div class="wrapper">
                  <data class="wrapper-item" value="1.7">1.7 ETH</data>

                  <span class="wrapper-item">1 of 1</span>
                </div>

                <button class="btn">
                  <ion-icon name="bag-add-outline" aria-hidden="true"></ion-icon>

                  <a href="placeabid.html"><span>Place a Bid</span></a>
                </button>

              </div>
            </li>

            <li>
              <div class="card explore-card">

                <figure class="card-banner">
                  <a href="#">
                    <img src="./assets/images/auction-11.jpg" width="600" height="600" loading="lazy"
                      alt="Cartoon Heroes" class="img-cover">
                  </a>
                </figure>

                <h3 class="h3 card-title">
                  <a href="#">Cartoon Heroes</a>
                </h3>

                <span class="card-author">
                  Owned By <a href="#" class="author-link">Junaid</a>
                </span>

                <div class="wrapper">
                  <data class="wrapper-item" value="3.2">3.2 ETH</data>

                  <span class="wrapper-item">1 of 1</span>
                </div>

                <button class="btn">
                  <ion-icon name="bag-add-outline" aria-hidden="true"></ion-icon>

                  <a href="placeabid.html"><span>Place a Bid</span></a>
                </button>

              </div>
            </li>

            <li>
              <div class="card explore-card">

                <figure class="card-banner">
                  <a href="#">
                    <img src="./assets/images/auction-12.jpg" width="600" height="600" loading="lazy" alt="Gaming Chair"
                      class="img-cover">
                  </a>
                </figure>

                <h3 class="h3 card-title">
                  <a href="#">Gaming Chair</a>
                </h3>

                <span class="card-author">
                  Owned By <a href="#" class="author-link">Johnson</a>
                </span>

                <div class="wrapper">
                  <data class="wrapper-item" value="0.69">0.69 ETH</data>

                  <span class="wrapper-item">1 of 1</span>
                </div>

                <button class="btn">
                  <ion-icon name="bag-add-outline" aria-hidden="true"></ion-icon>

                  <a href="placeabid.html"><span>Place a Bid</span></a>
                </button>

              </div>
            </li>

          </ul>

        </div>
      </section>




      <footer class="footer">

        <div class="footer-top section">
          <div class="container">
    
            <div class="footer-brand">
    
              <a href="#" class="logo">
                <img src="assets/images/logo.png" width="50" height="50" alt=" home">
              </a>
    
              
    
            </div>
    
      </footer>


  <!-- 
    - custom js link
  -->
  <script src="./assets/js/script.js" defer></script>

  <!-- 
    - ionicon-link
  -->
  <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
  <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>



</body>

</html>