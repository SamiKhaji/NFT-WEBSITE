<?php
if($_SERVER['REQUEST_METHOD']=='POST')
{
$email=$_POST['email'];
$password1=$_POST['password'];
$servername="localhost";
$username="root";
$password="";
$database="project1";

$conn=mysqli_connect($servername,$username,$password,$database);
if(!$conn)
{
echo "connection not successfull";
}
else
{
$sql="select email,password from signup where email='$email' and password='$password1'";
$result=mysqli_query($conn,$sql);
$count=mysqli_num_rows($result);
if($count>0)
{
    echo '<script>alert("login succesful")</script>';
    
    if(strpos($email,"user"))
    
    {
        echo '<script>alert("login succesful")</script>';
        header("Location:user_index.php");
        
    }
    else if(strpos($email,"celebrity"))
    {
        echo '<script>alert("login succesful")</script>';
        header("Location:index.php");
        
    }
    else
    {
        echo '<script>alert("please match the type")</script>';
    }
}
else
{
    header("Location:dl.php");
}
}

}
?>