<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <!-- 
    - primary meta tags
  -->
  <title>Nestostorm- Trusted & Secure Trading Nft website</title>
  <meta name="title" content="Nestostorm- Trusted & Secure Trading Nft website">
  <meta name="description" >

  <!-- 
    - favicon
  -->

  <!-- 
    - custom css link
  -->
  <link rel="stylesheet" href="Auction.css">

  <!-- 
    - google font link
  -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link
    href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;500;600;700&family=Poppins:wght@400;500;600;700;800&display=swap"
    rel="stylesheet">

  <!-- 
    - preload images
  -->
  <link rel="preload" as="image" href="./assets/images/hero-banner.png">
  
</head>

<body>

  <!-- 
    - #HEADER
  -->

  <header class="header" data-header>
    <div class="container">

      <a href="#" class="logo">
        <img src="./assets/images/logo.png" width="100" height="80" alt="Cryptoza home">
      </a>

      <nav class="navbar" data-navbar>

        <div class="navbar-top">

          <a href="#" class="logo">
            <img src="./assets/images/logo.svg" width="185" height="31" alt="home">
          </a>

          <button class="nav-close-btn" aria-label="close menu" data-nav-toggler>
            <ion-icon name="close-outline" aria-hidden="true"></ion-icon>
          </button>

        </div>

        <ul class="navbar-list">

          <li>
            <a href="index.php" class="navbar-link">Home</a>
          </li>

          <li>
            <a href="auction1.php" class="navbar-link">Explore</a>
          </li>

          <li>
            <a href="collection.php" class="navbar-link">Collection</a>
          </li>

          <li>
            <a href="Topseller1.php" class="navbar-link">TopSeller</a>
          </li>

          <li>
            <a href="contactus1.php" class="navbar-link">Contact</a>
          </li>

        </ul>

      </nav>

      <div class="btn-group">
        <a href="profile.php"><ion-icon name="menu-outline" aria-hidden="true"></ion-icon></a>
        
        <a href="wallet1.html" class="btn btn-primary" style="width: 300px;"><ion-icon name="wallet-outline"></ion-icon>
          Wallet</a>
      </div>

      <button class="nav-open-btn" aria-label="open menu" data-nav-toggler>
        <ion-icon name="menu-outline" aria-hidden="true"></ion-icon>
      </button>

      <div class="overlay" data-overlay data-nav-toggler></div>

    </div>
  </header>

  
      <section class="section explore" id="explore">
        <div class="container">

          <p class="section-subtitle">Exclusive Assets</p>

          <div class="title-wrapper">
            <h2 class="h2 section-title">NFT COLLECTION</h2>

            <a href="#" class="btn-link">
              <span>Explore All NFT'S</span>

              <ion-icon name="arrow-forward-outline" aria-hidden="true"></ion-icon>
            </a>
          </div>

          <ul class="grid-list">

            <li>
              <div class="card explore-card">

                <figure class="card-banner">
                  <a href="#">
                    <img src="./assets/images/auction-1.jpg" width="600" height="600" loading="lazy"
                      alt="Walking On Air" class="img-cover">
                  </a>
                </figure>

                <h3 class="h3 card-title">
                  <a href="#">Walking On Air</a>
                </h3>

                <span class="card-author">
                   Walking on air , dancing in the rain, refreshing and breezing
                </span>

                <div class="wrapper">
                  <data class="wrapper-item" value="1.5">Net Value: $1.5M ETH</data>

                  
                </div>
                <span class="wrapper-item">1 of 1</span>
                

              </div>
            </li>

            <li>
              <div class="card explore-card">

                <figure class="card-banner">
                  <a href="#">
                    <img src="./assets/images/auction-2.jpg" width="600" height="600" loading="lazy" alt="Domain Names"
                      class="img-cover">
                  </a>
                </figure>

                <h3 class="h3 card-title">
                  <a href="#">Domain Collectible</a>
                </h3>

                <span class="card-author">
                 Varying domains with wide possibilities to engrace profits and losses
                </span>

                <div class="wrapper">
                  <data class="wrapper-item" value="2.7">Net Value: $2.7M ETH</data>

                  
                </div>
                <span class="wrapper-item">1 of 1</span>

                

              </div>
            </li>

            <li>
              <div class="card explore-card">

                <figure class="card-banner">
                  <a href="#">
                    <img src="./assets/images/auction-3.jpg" width="600" height="600" loading="lazy" alt="Trading Cards"
                      class="img-cover">
                  </a>
                </figure>

                <h3 class="h3 card-title">
                  <a href="#">Trading Cards</a>
                </h3>

                <span class="card-author">
                 Cards are traded as in a way lives are traded in the midst of sorrow and happiness
                </span>

                <div class="wrapper">
                  <data class="wrapper-item" value="2.3">Net Value: $2.3M ETH</data>

                 
                </div>
                <span class="wrapper-item">1 of 1</span>
                

              </div>
            </li>

            <li>
              <div class="card explore-card">

                <figure class="card-banner">
                  <a href="#">
                    <img src="./assets/images/auction-4.jpg" width="600" height="600" loading="lazy"
                      alt="Industrial Revolution" class="img-cover">
                  </a>
                </figure>

                <h3 class="h3 card-title">
                  <a href="#">Industrial Revolution</a>
                </h3>

                <span class="card-author">
                 New revolutionized industrial aspects are being reformed and upgraded
                </span>

                <div class="wrapper">
                  <data class="wrapper-item" value="1.8">Net Value: $1.8M ETH</data>

                  
                </div>
                <span class="wrapper-item">1 of 1</span>
        

              </div>
            </li>

            

          </ul>

<br>
            <h2 class="h2 section-title text-center">Sold NFT Assets</h2>
  
            <p class="section-text text-center">
             
            </p>
            <ul class="grid-list">

                <li>
                    <div class="card explore-card">
      
                      <figure class="card-banner">
                        <a href="#">
                          <img src="./assets/images/auction-6.jpg" width="600" height="600" loading="lazy" alt="Sports"
                            class="img-cover">
                        </a>
                      </figure>
      
                      <h3 class="h3 card-title">
                        <a href="#">Sports</a>
                      </h3>
      
                      <span class="card-author">
                        Sunil Chetri 45th minute goal digital image nft is kept for sale. Hurry Soon!!
                      </span>
      
                      <div class="wrapper">
                        <data class="wrapper-item" value="1.7">Purchase Value: $1.7M ETH</data>
                        
      
      
                        
                      </div>
                      <div class="wrapper">
                        
                        <data class="wrapper-item" value="1.7">Sold Value: $2.5M ETH</data>
      
      
                        
                      </div>
                      <span class="wrapper-item">1 of 1</span>
                      
                    </div>
                  </li>
    
                  <li>
                    <div class="card explore-card">
      
                      <figure class="card-banner">
                        <a href="#">
                          <img src="./assets/images/auction-7.jpg" width="600" height="600" loading="lazy"
                            alt="Cartoon Heroes" class="img-cover">
                        </a>
                      </figure>
      
                      <h3 class="h3 card-title">
                        <a href="#">Cartoon Heroes</a>
                      </h3>
      
                      <span class="card-author">
                       Ultimate Ben 10 Nfts are for sale. Grab them as quick as possible!!
                      </span>
      
                      <div class="wrapper">
                        <data class="wrapper-item" value="3.2">Purchase Value:$3.2M ETH</data>
      
                        
                      </div>
                      <div class="wrapper">
                        <data class="wrapper-item" value="3.2">Sold Value:$3.7M ETH</data>
      
                        
                      </div>
                      <span class="wrapper-item">1 of 1</span>
                      
      
                    </div>
                  </li>
    
                  <li>
                    <div class="card explore-card">
      
                      <figure class="card-banner">
                        <a href="#">
                          <img src="./assets/images/auction-8.jpg" width="600" height="600" loading="lazy" alt="Gaming Chair"
                            class="img-cover">
                        </a>
                      </figure>
      
                      <h3 class="h3 card-title">
                        <a href="#">Gaming Chair</a>
                      </h3>
      
                      <span class="card-author">
                        Latest version of ps5 gaming nfts are making higher bids. Place your Bid!!
                      </span>
      
                      <div class="wrapper">
                        <data class="wrapper-item" value="0.69">Purchase Value:$0.69M ETH</data>
      
                        
                      </div>
                      <div class="wrapper">
                        <data class="wrapper-item" value="0.69">Sold Value:$1.6M ETH</data>
      
                        
                      </div>
                      <span class="wrapper-item">1 of 1</span>
                      
      
                    </div>
                  </li>
    
                  <li>
                    <div class="card explore-card">
      
                      <figure class="card-banner">
                        <a href="#">
                          <img src="./assets/images/auction-9.jpg" width="600" height="600" loading="lazy" alt="Utility"
                            class="img-cover">
                        </a>
                      </figure>
      
                      <h3 class="h3 card-title">
                        <a href="#">Utility</a>
                      </h3>
      
                      <span class="card-author">
                        An unique utility digital image nft is available. Have a look!!
                      </span>
      
                      <div class="wrapper">
                        <data class="wrapper-item" value="1.7">Purchase Value:$1.7M ETH</data>
      
                        
                      </div>
                      <div class="wrapper">
                        <data class="wrapper-item" value="1.7">Sold Value:$2.4M ETH</data>
      
                        
                      </div>
                      <span class="wrapper-item">1 of 1</span>
                      
      
                    </div>
                  </li>
                
    
              </ul>
    
</div>    

            
            
            
      </section>





  
</body>

</html>