<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile</title>

    <!-- ===== ===== Custom Css ===== ===== -->
    <link rel="stylesheet" href="profile.css">
    <link rel="stylesheet" href="prores.css">

    <!-- ===== ===== Remix Font Icons Cdn ===== ===== -->
    <link rel="stylesheet" href="fonts/remixicon.css">
</head>

<body style="font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;background-color: antiquewhite;">
    <!-- ===== ===== Body Main-Background ===== ===== -->
    <span class="main_bg"></span>


    <!-- ===== ===== Main-Container ===== ===== -->
    <div class="container">

        <!-- ===== ===== Header/Navbar ===== ===== -->
       


        <!-- ===== ===== User Main-Profile ===== ===== -->
        <section class="userProfile card">
            <div class="profile">
                <figure><img src="assets/images/avatar-1.jpg" alt="profile" width="250px" height="250px"></figure>
            </div>
        </section>


            <!-- ===== ===== Skills Contaienr ===== ===== -->
            
        </section>


        <!-- ===== ===== User Details Sections ===== ===== -->
        <section class="userDetails card">
            <div class="userName">
                <h1 class="name">Shahrukh</h1>
                <div class="map">
                    <i class="ri-map-pin-fill ri"></i>
                    <span>Mumbai,IND</span>
                </div>
                <p>Actor</p>
            </div>

            <div class="rank">
                <h1 class="heading">Rankings</h1>
                <span>7th</span>
                <p>One of the Most Famous Personalities in india with More than 2B followers and more than 200 B worth.Truely the badshah of India</p>
                <div class="rating">
                    <i class="ri-star-fill rate"></i>
                    <i class="ri-star-fill rate"></i>
                    <i class="ri-star-fill rate"></i>
                    <i class="ri-star-fill rate"></i>
                    <i class="ri-star-fill rate underrate"></i>
                </div>
            </div>

            <div class="btns">
                <ul>
                     
                    

                    <li class="sendMsg">
                        <a href="#">Report User</a>
                    </li>
                </ul>
            </div>
        </section>



        <!-- ===== ===== Timeline & About Sections ===== ===== -->
        <section class="timeline_about card">
            <div class="tabs">
                <ul>
                    <li class="about active">
                        <i class="ri-eye-fill ri"></i>
                        <a href="assets.html"><span>Assets</span></a>
                    </li>
                    <li class="">
                        <i class="ri-user-3-fill ri"></i>
                        <a href="profile.php"><span>About</span></a>
                    </li>



                </ul>
            </div>

            <div class="contact_Info">
                <div class="img_container">
                    <div class="inner_content"><img
                            src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQNb-lYniAxBOvBTHROh4XhuykQXd8pJMSpRg&usqp=CAU"
                            height="200" width="350">
                        <div class="content">
                            &ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;MUSIC NFT
                        </div>
                    </div>
                </div>
                <div class="img_container">
                    <div class="inner_content"><img
                            src="https://imgv3.fotor.com/images/slider-image/goart_guide_pc_now_3.jpg"
                            height="200" width="350">
                        <div class="content">
                            &ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;PAINTING NFT
                        </div>
                    </div>
                </div>
                <div class="img_container">
                    <div class="inner_content"><img
                            src="https://miro.medium.com/max/1400/0*PGN7T9bp5QQTxM10.jpeg"
                            height="200" width="350">
                        <div class="content">
                            &ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;GAMING NFT
                        </div>
                    </div>
                </div>
                <div class="img_container">
                    <div class="inner_content"><img
                            src="https://blockchainreporter.net/wp-content/uploads/2021/11/disney-iron-man-simpsons-nft.jpeg"
                            height="200" width="350">
                        <div class="content">
                            &ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;COLLECTIBLES NFT
                        </div>
                    </div>
                </div>
                

            </div>
        </section>
    </div>

</body>
<style>
    .contact_info {
        display: inline-block;
    }
    .img_container{
        display: inline-block;
        margin: 10px;
    }

    .inner_content {

        
        width: fit-content;


    }

    .content {
        display: flex;
        align-items: center;

    }
</style>

</html>