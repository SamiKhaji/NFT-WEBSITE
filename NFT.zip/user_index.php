<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <!-- 
    - primary meta tags
  -->
  <title>Nestostorm- Trusted & Secure Trading Nft website</title>
  <meta name="title" content="Neftostorm- Trusted & Secure Trading Nft website">
  <meta name="description" >


  <!-- 
    - custom css link
  -->
  <link rel="stylesheet" href="./assets/css/style.css">

  <!-- 
    - google font link
  -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link
    href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;500;600;700&family=Poppins:wght@400;500;600;700;800&display=swap"
    rel="stylesheet">

  <!-- 
    - preload images
  -->
  <link rel="preload" as="image" href="./assets/images/logo.png">

</head>

<body>

  <!-- 
    - #HEADER
  -->

  <header class="header" data-header>
    <div class="container">

      <a href="#" >
        <img src="assets/images/logo.png" width="100" height="100" alt=" home">
      </a>

      <nav class="navbar" data-navbar>

        <div class="navbar-top">

          <a href="#">
            <img src="assets/images/logo.png" width="185" height="31" alt="home">
          </a>

          <button class="nav-close-btn" aria-label="close menu" data-nav-toggler>
            <ion-icon name="close-outline" aria-hidden="true"></ion-icon>
          </button>

        </div>

        <ul class="navbar-list">

          <li>
            <a href="user_index.php" class="navbar-link">Home</a>
          </li>

          <li>
            <a href="auction.php" class="navbar-link">Explore</a>
          </li>

          


          <li>
            <a href="Topseller.php" class="navbar-link">TopSeller</a>
          </li>

          <li>
            <a href="contactus.php" class="navbar-link">Contact</a>
          </li>

        </ul>

      </nav>

      <div class="btn-group">
        <a href="dl.php" class="btn ghost-btn" onclick="reload1()">Logout</a>
        
        <a href="dummy.php" class="btn btn-primary" style="width: 300px;"><ion-icon name="wallet-outline"></ion-icon>
          Wallet</a>
      </div>

      <button class="nav-open-btn" aria-label="open menu" data-nav-toggler>
        <ion-icon name="menu-outline" aria-hidden="true"></ion-icon>
      </button>

      <div class="overlay" data-overlay data-nav-toggler></div>

    </div>
  </header>





  <main>
    <article>

      <!-- 
        - #HERO
      -->

      <section class="hero" aria-label="home">
        <div class="container">

          <div class="hero-content">

            <h1 class="h1 hero-title">Discover, collect, and sell extraordinary NFTs</h1>

            <p class="hero-text">
              Explore on the world's best & largest NFT marketplace
            </p>

          </div>

          <div class="hero-banner">
            <figure class="hero-banner">
              <img src="https://comicyears.com/wp-content/uploads/2022/04/FarPub1.png" width="900" height="823" alt="hero banner" class="w-100">
            </figure>
          </div>

        </div>
      </section>





      <!-- 
        - #PROMO
      -->

      <section class="section promo" aria-label="promo">
        <div class="container">

          <h2 class="h2 section-title text-center">Exclusive assets</h2>

          <p class="section-text text-center">
           
          </p>

          <ul class="grid-list">

            <li>
              <div class="promo-card bg-gray">
                <h2 class="h3 card-title">Music</h2>
                <br>
                <img src="assets/images/music.jpg" width="300" height="400" loading="lazy"
                      alt="Walking On Air" class="img-cover" >
                <p class="card-text">
                  Music is one of the integral parts of every persons life, and it is present everywhere. The cacophony of birds during the early morning hours or the gentle rustling of leaves as the breeze passes by a tree; everything has music in it if you have the ear for it and it is present everywhere.
                </p> 
              </div>
            </li>

            <li>
              <div class="promo-card bg-gray">
                <h2 class="h3 card-title">ART WORK</h2>
                <br>
                <img src="assets/images/art.jpg" width="300" height="400" loading="lazy"
                      alt="Walking On Air" class="img-cover" >
                <p class="card-text">
                  any creative work of a human being  is a diverse range of human activity, and resulting product, that involves creative or imaginative talent expressive of technical proficiency, beauty, emotional power, or conceptual ideas. any creative work of a human being 
                </p> 
              </div>
            </li>

            <li>
              <div class="promo-card bg-gray">
                <h2 class="h3 card-title">GAMING</h2>
                <br>
                <img src="assets/images/games.jpg" width="300" height="400" loading="lazy"
                      alt="Walking On Air" class="img-cover" >
                <p class="card-text">
                  Music is one of the integral parts of every persons life, and it is present everywhere. The cacophony of birds during the early morning hours or the gentle rustling of leaves as the breeze passes by a tree; everything has music in it if you have the ear for it
                </p> 
              </div>
            </li>

          </ul>

        </div>
      </section>





      <!-- 
        - #STATS
      -->

      <section class="stats" aria-label="statistics">
        <div class="container">

          <div class="stats-content">

            <h2 class="h2 section-title">Our Best celebrities Are all over the india and users are Worldwide Coverage</h2>

            <p class="section-text">
              You might wonder why a designer would choose to use Morem text Paragraphs Lorem Ipsum available but the
              majority
            </p>

            <p class="section-text">
              embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat
              predefined
              chunks as necessary, making this the first true generator on the Internet.
            </p>

            <ul class="stats-list">

              <li>
                <div class="stats-card bg-gray">

                  <h3 class="h3 card-title">150k+</h3>

                  <p class="card-text">
                    Pepole who Have buyed
                  </p>

                </div>
              </li>

              <li>
                <div class="stats-card bg-gray">

                  <h3 class="h3 card-title">45k+</h3>

                  <p class="card-text">
                    celebrities available
                  </p>

                </div>
              </li>

              <li>
                <div class="stats-card bg-gray">

                  <h3 class="h3 card-title">16k+</h3>

                  <p class="card-text">
                    Nfts sold and traded     
                  </p>

                </div>
              </li>

            </ul>

          </div>

          <figure class="stats-banner">
            <img src="./assets/images/stats-banner.png" width="797" height="454" alt="map" class="w-100">
          </figure>

        </div>
      </section>





      <!-- 
        - #MARKET
      -->

      <section class="section market" aria-label="crypto market live price">
        <div class="container">

          <h2 class="h2 section-title text-center">Nft index </h2>

          <p class="section-text text-center">
            Marrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat
            predefined true
            generator.
          </p>

          <div class="table-container">
            <table class="market-table">

              <thead class="table-head">
                <tr class="table-row">

                  <th class="table-heading">crypto type</th>

                  <th class="table-heading">nft type</th>

                  <th class="table-heading">sold by</th>

                  <th class="table-heading">Auction date</th>

                  <th class="table-heading">Final bid</th>

                </tr>
              </thead>

              <tbody class="table-body">

                <tr class="table-row">

                  <td class="table-data wrapper">
                    <img src="./assets/images/coin-1.png" width="64" height="64" loading="lazy" alt="BTC">

                    <div>
                      <h3 class="h3 coin-name">Bitcoin</h3>

                      <span class="span">BTC</span>
                    </div>
                  </td>

                  <td class="table-data">
                    <data class="data" value="39000">Music</data>
                  </td>

                  <td class="table-data">
                    <div class="wrapper-flex">
                      <div class="icon red">
                        <ion-icon name="caret-up" aria-hidden="true"></ion-icon>
                      </div>

                      <data class="data" value="-0.04%">Arjit Singh</data>
                    </div>
                  </td>

                  <td class="table-data">
                    <div class="wrapper-flex">
                      <div class="icon red">
                        <ion-icon name="caret-up" aria-hidden="true"></ion-icon>
                      </div>

                      <data class="data" value="-3.26%">10/12/2020</data>
                    </div>
                  </td>

                  <td class="table-data">
                    <div class="wrapper-flex">
                      <div class="icon red">
                        <ion-icon name="caret-up" aria-hidden="true"></ion-icon>
                      </div>

                      <data class="data" value="-7.82%">8.5B</data>
                    </div>
                  </td>

                </tr>

                <tr class="table-row">

                  <td class="table-data wrapper">
                    <img src="./assets/images/coin-2.png" width="64" height="64" loading="lazy" alt="ETH">

                    <div>
                      <h3 class="h3 coin-name">Ethereum</h3>

                      <span class="span">ETH</span>
                    </div>
                  </td>

                  <td class="table-data">
                    <data class="data" value="2896">PAINTING</data>
                  </td>

                  <td class="table-data">
                    <div class="wrapper-flex">
                      <div class="icon red">
                        <ion-icon name="caret-up" aria-hidden="true"></ion-icon>
                      </div>

                      <data class="data" value="-0.6%">Shahrukh khan</data>
                    </div>
                  </td>

                  <td class="table-data">
                    <div class="wrapper-flex">
                      <div class="icon red">
                        <ion-icon name="caret-up" aria-hidden="true"></ion-icon>
                      </div>

                      <data class="data" value="-4.73%">4/10/22</data>
                    </div>
                  </td>

                  <td class="table-data">
                    <div class="wrapper-flex">
                      <div class="icon red">
                        <ion-icon name="caret-up" aria-hidden="true"></ion-icon>
                      </div>

                      <data class="data" value="-8.89%">5.2ETH</data>
                    </div>
                  </td>

                </tr>

                <tr class="table-row">

                  <td class="table-data wrapper">
                    <img src="./assets/images/coin-3.png" width="64" height="64" loading="lazy" alt="USDT">

                    <div>
                      <h3 class="h3 coin-name">Tether</h3>

                      <span class="span">USDT</span>
                    </div>
                  </td>

                  <td class="table-data">
                    <data class="data" value="1">Gaming</data>
                  </td>

                  <td class="table-data">
                    <div class="wrapper-flex">
                      <div class="icon red">
                        <ion-icon name="caret-up" aria-hidden="true"></ion-icon>
                      </div>

                      <data class="data" value="-0.01%">Dynamo</data>
                    </div>
                  </td>

                  <td class="table-data">
                    <div class="wrapper-flex">
                      <div class="icon red">
                        <ion-icon name="caret-up" aria-hidden="true"></ion-icon>
                      </div>

                      <data class="data" value="-0.05%">10/2/22</data>
                    </div>
                  </td>

                  <td class="table-data">
                    <div class="wrapper-flex">
                      <div class="icon red">
                        <ion-icon name="caret-up" aria-hidden="true"></ion-icon>
                      </div>

                      <data class="data" value="-0.04%">10T</data>
                    </div>
                  </td>

                </tr>

                

                <tr class="table-row">

                  <td class="table-data wrapper">
                    <img src="./assets/images/coin-5.png" width="64" height="64" loading="lazy" alt="USDC">

                    <div>
                      <h3 class="h3 coin-name">USD Coin</h3>

                      <span class="span">USDC</span>
                    </div>
                  </td>

                  <td class="table-data">
                    <data class="data" value="0">Accesories</data>
                  </td>

                  <td class="table-data">
                    <div class="wrapper-flex">
                      <div class="icon red">
                        <ion-icon name="caret-down" aria-hidden="true"></ion-icon>
                      </div>

                      <data class="data" value="-0.04%">Virat kohli</data>
                    </div>
                  </td>

                  <td class="table-data">
                    <div class="wrapper-flex">
                      <div class="icon red">
                        <ion-icon name="caret-up" aria-hidden="true"></ion-icon>
                      </div>

                      <data class="data" value="-0.13%">5/5/20</data>
                    </div>
                  </td>

                  <td class="table-data">
                    <div class="wrapper-flex">
                      <div class="icon green">
                        <ion-icon name="caret-up" aria-hidden="true"></ion-icon>
                      </div>

                      <data class="data" value="0.05%">20005USD</data>
                    </div>
                  </td>

                </tr>

                
                <tr class="table-row">

                  <td class="table-data wrapper">
                    <img src="./assets/images/coin-7.png" width="64" height="64" loading="lazy" alt="SOL">

                    <div>
                      <h3 class="h3 coin-name">Solana</h3>

                      <span class="span">SOL</span>
                    </div>
                  </td>

                  <td class="table-data">
                    <data class="data" value="95">Image</data>
                  </td>

                  <td class="table-data">
                    <div class="wrapper-flex">
                      <div class="icon red">
                        <ion-icon name="caret-up" aria-hidden="true"></ion-icon>
                      </div>

                      <data class="data" value="-0.81%">Rajini Kanth</data>
                    </div>
                  </td>

                  <td class="table-data">
                    <div class="wrapper-flex">
                      <div class="icon red">
                        <ion-icon name="caret-up" aria-hidden="true"></ion-icon>
                      </div>

                      <data class="data" value="-6.06%">20/8/22</data>
                    </div>
                  </td>

                  <td class="table-data">
                    <div class="wrapper-flex">
                      <div class="icon red">
                        <ion-icon name="caret-up" aria-hidden="true"></ion-icon>
                      </div>

                      <data class="data" value="-13.66%">500SOL</data>
                    </div>
                  </td>

                </tr>


                <tr class="table-row">

                  <td class="table-data wrapper">
                    <img src="./assets/images/coin-10.png" width="64" height="64" loading="lazy" alt="AVAX">

                    <div>
                      <h3 class="h3 coin-name">Avalanche</h3>

                      <span class="span">AVAX</span>
                    </div>
                  </td>

                  <td class="table-data">
                    <data class="data" value="73">Accesories</data>
                  </td>

                  <td class="table-data">
                    <div class="wrapper-flex">
                      <div class="icon red">
                        <ion-icon name="caret-up" aria-hidden="true"></ion-icon>
                      </div>

                      <data class="data" value="-0.63%">Rohith Sharma</data>
                    </div>
                  </td>

                  <td class="table-data">
                    <div class="wrapper-flex">
                      <div class="icon red">
                        <ion-icon name="caret-up" aria-hidden="true"></ion-icon>
                      </div>

                      <data class="data" value="-6.23%">12/01/21</data>
                    </div>
                  </td>

                  <td class="table-data">
                    <div class="wrapper-flex">
                      <div class="icon red">
                        <ion-icon name="caret-up" aria-hidden="true"></ion-icon>
                      </div>

                      <data class="data" value="-11.01%">100AVAX</data>
                    </div>
                  </td>

                </tr>

              </tbody>

            </table>
          </div>

        </div>
      </section>





      <section class="section instruction" aria-label="instruction">
        <div class="container">

          <h2 class="h2 section-title text-center">How it Works</h2>

          <p class="section-text text-center">
            There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in
            some form,
            by injected
          </p>

          <ul class="grid-list">

            <li>
              <div class="instruction-card bg-gray">

                <div class="card-icon">
                  <ion-icon name="wallet-outline"></ion-icon>                </div>
                <center><h3 style="color: white;">Create and sell your NFTs</h3></center>

                <p class="card-text">
                  Once youve set up your wallet of choice, connect it to OpenSea by clicking the NFT Marketplace in the
                top right corner.
                Learn about the wallets we support.
                </p>

              </div>
            </li>

            <li>
              <div class="instruction-card bg-gray">

                <div class="card-icon">
                  <ion-icon name="wallet-outline"></ion-icon>                </div>
                <center><h3 style="color: white;">Create your collection</h3></center>

                <p class="card-text">
                  
                Click Create and set up your collection. Add social links, a description, profile & banner images, and
                set a secondary
                sales fee.
                sales fee and you can create the collection.
              
                </p>

              </div>
            </li>

            <li>
              <div class="instruction-card bg-gray">

                <div class="card-icon">
                  <ion-icon name="wallet-outline"></ion-icon>                </div>
                <center><h3 style="color: white;">Add your NFTs</h3></center>

                <p class="card-text">
                  
                Upload your work (image, video, audio, or 3D art), add a title and description, and customize your NFTs
                with properties,
                stats, and unlockable content. and nfts can be added
              
                </p>

              </div>
            </li>

             <li>
              <div class="instruction-card bg-gray">

                <div class="card-icon">
                  <ion-icon name="wallet-outline"></ion-icon>                </div>
                <center><h3 style="color: white;">List them for sale</h3></center>

                <p class="card-text">
                  
                Choose between auctions, fixed-price listings, and declining-price listings. You choose how you want to
                sell your NFTs!.then nfts will be listed for sale,you can also choose one time bid
              
                </p>

              </div>
            </li>

          </ul>

        </div>
      </section>



      <!-- 
        - #APP
      -->

      <section class="app" aria-label="app">
        <div class="container">

          <div class="app-card bg-gray">

            <div class="card-content">

              <h2 class="h2 section-title">Explore Our celebrities</h2>

              <p class="section-text">
                You can Explore our Celebrities If you like them please follow them.
              </p>
<a href="auction.html"><div class="btn-group" >

  <a href="#" class="btn btn-primary">
    


    <div onclick="reload()" >
      <p class="btn-text">Follow and </p>
      <p class="btn-title" onclick="reload()">Explore in Explore Section</p>
    </div>
  </a>

  
</div>


</div>

<figure class="card-banner">
<img src="./assets/images/download-banner.png" width="383" height="384" loading="lazy"
  alt="download banner" class="w-100">
</figure>

</div></a>
              

        </div>
      </section>

    </article>
  </main>





  <!-- 
    - #FOOTER
  -->

  <footer class="footer">

    <div class="footer-top section">
      <div class="container">

        <div class="footer-brand">

          <a href="#" class="logo">
            <img src="assets/images/logo.png" width="50" height="50" alt=" home">
          </a>

          

        </div>

  </footer>





  <!-- 
    - custom js link
  -->
  <script src="./assets/js/script.js" defer></script>

  <!-- 
    - ionicon-link
  -->
  <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
  <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>

</body>
<script>
  function reload()
  {
    window.open("topseller.html")
  }
  function reload1()
  {
    window.alert("successfully logged out")
  }
</script>
</html>