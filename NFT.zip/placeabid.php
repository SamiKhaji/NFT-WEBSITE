<?php


// Check if the form has been submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  // Get the bid amount and auction item ID from the form
  $bid_amount = $_POST['bid_amount'];
  $auction_item_id = $_POST['auction_item_id'];
  $servername="localhost";
  $username="root";
$password="";
$database="project1";

// Connect to the database
$conn=mysqli_connect($servername,$username,$password,$database);
  // Check if the bid amount is higher than the current highest bid
  $result = $conn->query("SELECT MAX(bid_amount) FROM bids WHERE auction_item_id = $auction_item_id");
  $highest_bid = $result->fetch_row()[0];
}
  

?>

<html>
    <head>
        <link rel="stylesheet" href="">
        <style>
            .container{
                display: flex;
                justify-content: flex-start;
                align-items: center;
                margin: auto;
                margin-top: 12rem;
                box-shadow: 2px 2px 2px 2px rgb(21, 203, 231);
                border-radius: 5px;
                width: 70%;
                padding: 30px;
                height: 30vh !important;
            }
            .ring{
            
                border-radius: 5px;
                
            }
            .content{
                margin-left: 20px;
                display: flex;
            }
            .column{
                display: inline-block;
                border-right: 2px solid white;
            }
            .jinka{
                display: flex;
                justify-content: flex-end;
                align-items: center;
                margin: auto;
                margin-top: 4rem;
                box-shadow: 2px 2px 2px 2px rgb(21, 203, 231);
                border-radius: 5px;
                width: 60%;
                padding: 20px;
        
               
                
            }
            .jinka >button{
                margin-left: 20px;
            }
            .rumble{
                
                display: inline-flex;
                justify-content: space-between !important;
                align-items: center;
                margin-left: 100px;
            }
        </style>
    </head>
    <body style="background-color:hsl(40, 100%, 2%);color: white;font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;">
        <marquee><div style="color: red;background-color: rgb(0, 0, 0);font-size: 20px;font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;">Auction closes in <span id="time"></span> minutes! and Current Highest Bid: <?php echo "$highest_bid" ?></div></marquee>
        <div id="response"></div>
        
        <div class="container">
    <div class="ring">
        <img src="assets/images/auction-1.jpg" height="200px">
    </div>
    <div class="content">
        
        <div class="row">
            <div class="column">
              <label style="opacity: 0.5;">Owned by:</label>
              <blockquote><p><em id="beneficiary">Richards</em><br /><br /></p></blockquote>
            </div>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <div class="column">
              <label style="opacity: 0.5;">Raised:</label>
              <blockquote><p><em><span id="raised">1.3B</span><br />ETH</em></p></blockquote>
            </div>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <div class="column">
              <label style="opacity: 0.5;">Highest Bidder:</label>
              <blockquote><p><em><span id="highestBidder"></span><br />

              <span id="highestBid"></span><?php echo $highest_bid; ?> </em></p></blockquote>
            </div>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <div class="column"></div>
            <div class="column"></div>
            <div class="column">
              <label style="opacity: 0.5;">No of bids<label>
              <blockquote><p><em id="accountAddress">2.5k...</em><br /><br /></p></blockquote>
            </div>

          </div>
      
          
    </div>
    </div>
    <div class="jinka">
        
      
          <div class="row">
            <div class="rumble">
              <label>From Account</label>
              <select id="bidAccount">
                <option>crypto account</option>
                <option>wallet</option>
              </select>
            </div>
            <div class="rumble">
              <?php 
// Display the bid form and message (if any) to the user
echo '<form method="post">';
echo '<input type="hidden" name="auction_item_id" value="4">';
echo '<label for="bid_amount">Enter your bid:</label>';
echo '<input type="number" name="bid_amount" required>';
echo '<button id="makeBid"type="submit" onclick="reload1()">Bid</button>';
echo '</form>'; 

if ($bid_amount > $highest_bid) {
    // Insert the new bid into the database
    $conn->query("INSERT INTO bids (auction_item_id, bid_amount) VALUES ($auction_item_id, $bid_amount)");
    
    $message = 'Your bid was successful.';
    echo "$message";
    
    
        

  } 
  else if($bid_amount < $highest_bid)
  {
    
    $message = 'Your bid was not successful';
    echo "$message";
  }
  else{}
?>
              &nbsp;&nbsp;&nbsp;

              </div>
            <div class="rumble">
              <label><br /></label>
              <button id="endAuction" disabled="disabled">End Auction</button>
            </div>
          </div>
          
      
        
    </div>
      
    
        </body>
        </html>