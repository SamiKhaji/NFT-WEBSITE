<?php
$servername="localhost";
$username="root";
$password="";
$database="project1";
// Connect to the database
$conn=mysqli_connect($servername,$username,$password,$database);


// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize the wallet balance to 0
$balance = 0;

// Check if the user has a balance in the database
$sql = "SELECT balance FROM wallet WHERE user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$stmt->bind_result($balance);
$stmt->fetch();

// If the user does not have a balance, insert a new record into the database
if ($balance == 0) {
    $sql = "INSERT INTO wallet (user_id, balance) VALUES (?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $user_id, $balance);
    $stmt->execute();
}

// Function to add funds to the wallet
function addFunds($amount) {
    global $balance;
    global $conn;
    global $user_id;

    // Update the balance in the database
    $balance += $amount;
    $sql = "UPDATE wallet SET balance = ? WHERE user_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $balance, $user_id);
    $stmt->execute();
}

// Function to check the balance
function checkBalance() {
    global $balance;
    return $balance;
}

// Example usage:
addFunds(200);

?>

<!DOCTYPE html>
<html>
<head>
<title>E-Wallet App UI Design</title>
<link rel="stylesheet" href="style.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link
    href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;500;600;700&family=Poppins:wght@400;500;600;700;800&display=swap"
    rel="stylesheet">
<style>
    body
{
    background-color: #3fb0ef !important;
}
.wallet-container
{
    background: linear-gradient(rgba(0,0,0,0.6), rgba(0,0,0,0.6)), url("C:\Users\hp\Desktop\a.jpg");
    width: 320px;
    color: #fff;
    font-size: 15px;
    padding: 20px 20px 0;
    top: 50%;
    left: 50%;
    transform: translate(-50%,-50%);
    position: absolute;
}
.page-title
{
    text-align: left;
}
.fa-user
{
    float: right;
}
.fa-align-left
{
    margin-right: 15px;
}
.amount-box img
{
    width: 50px;
}
.amount
{
    font-size: 35px;
}
.amount-box p
{
    margin-top: 10px;
    margin-bottom: -10px;
}
.btn-group
{
    margin: 20px 0;
}
.btn-group .btn
{
    margin: 8px;
    border-radius: 20px !important;
    font-size: 12px;
}
.txn-history
{
    text-align: left;
}
.txn-list
{
    background-color: #fff;
    padding: 12px 10px;
    color: #777;
    font-size: 14px;
    margin: 7px 0;
}
.debit-amount
{
    color: red;
    float: right;
}
.credit-amount
{
    color: green;
    float: right;
}
.footer-menu
{
    margin: 20px -20px 0;
    bottom: 0;
    border-top: 1px solid #ccc;
    padding: 1opx 10px 0;
}
.fotter-menu p
{
    font-size: 12px;
}
</style>
</head>
<body>
    
<div class="wallet-container text-center">
<p class="page-title"><i class="fa fa-align-left"></i>My E-Wallet<i class="fa fa-user"></i>
</p>
<div class="amount-box text-center">
    <i class='fas fa-wallet'>
<p>Total Balance</p>
<p class="amount">$<?php echo checkbalance() ?></p>
</div>
<div class="btn-group text-center">
<button type="button" class="btn btn-outline-light">Add Money</button>
<button type="button" class="btn btn-outline-light">Widthdraw</button>
</div>
<div class="txn-history">
<p><b>History</b></p>
<p class="txn-list">Payment to music nft<span class="debit-amount">-100$</span></p>

<p class="txn-list">withdraw done<span class="debit-amount">-150$</span></p>

<p class="txn-list">Credit From  ltd nft <span class="credit-amount">+300$</span></p>

<p class="txn-list">Transfer from Sami<span class="credit-amount">+100$</span></p>
</div>
<div class="footer-menu">
<div class="row text-center">
    
    <center><div class="col-md-3">
        <a href="user_index.php"><i class="fa fa-home"></i></a>
        <p>Home</p>
        </div></center>
    
    
</div>
</div>
</div>
</body>
</html>