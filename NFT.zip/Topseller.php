
 <!DOCTYPE html>
 <html lang="en">
 
 <head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
 
   <!-- 
     - primary meta tags
   -->
   <title>Nestostorm- Trusted & Secure Trading Nft website</title>
   <meta name="title" content="Nestostorm- Trusted & Secure Trading Nft website">
   <meta name="description" >
 
   <!-- 
     - favicon
   -->
 
   <!-- 
     - custom css link
   -->
   <link rel="stylesheet" href="topseller.css">
 
   <!-- 
     - google font link
   -->
   <link rel="preconnect" href="https://fonts.googleapis.com">
   <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
   <link
     href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;500;600;700&family=Poppins:wght@400;500;600;700;800&display=swap"
     rel="stylesheet">
 
   <!-- 
     - preload images
   -->
   <link rel="preload" as="image" href="./assets/images/hero-banner.png">
 
 </head>
 
 <body>
 
   <!-- 
     - #HEADER
   -->
 
   <header class="header" data-header>
     <div class="container">
 
       <a href="#" class="logo">
        <img src="assets/images/logo.png" width="100" height="100" alt=" home">
       </a>
 
       <nav class="navbar" data-navbar>
 
         <div class="navbar-top">
 
           <a href="#" class="logo">
             <img src="./assets/images/logo.svg" width="100" height="31" alt="home">
           </a>
 
           <button class="nav-close-btn" aria-label="close menu" data-nav-toggler>
             <ion-icon name="close-outline" aria-hidden="true"></ion-icon>
           </button>
 
         </div>
 
         <ul class="navbar-list">
 
           <li>
             <a href="user_index.php" target="_top" class="navbar-link">Home</a>
           </li>
 
           <li>
             <a href="auction.php" class="navbar-link">Explore</a>
           </li>
 <li>
            <a href="Topseller.php" class="navbar-link">TopSeller</a>
          </li>
 
           <li>
             <a href="contactus.php" class="navbar-link">Contact</a>
           </li>
 
         </ul>
 
       </nav>
 
       <div class="btn-group">
         <a href="dl.php" class="btn ghost-btn">Sign In</a>
         
         <a href="wallet.html" class="btn btn-primary" style="width: 300px;"><ion-icon name="wallet-outline"></ion-icon>
           Wallet</a>
       </div>
 
       <button class="nav-open-btn" aria-label="open menu" data-nav-toggler>
         <ion-icon name="menu-outline" aria-hidden="true"></ion-icon>
       </button>
 
       <div class="overlay" data-overlay data-nav-toggler></div>
 
     </div>
   </header>
 
 
 
 
 
   <main>
     <article>
 
       
 
 <section class="section top-seller" id="top-seller">
        <div class="container">

          <p class="section-subtitle">Creative Artist</p>

          <h2 class="h2 section-title">Top Sellers</h2>

          <ul class="grid-list">

            <li>
              <div class="card top-seller-card">

                <figure class="card-avatar">
                  <a href="profile.html">
                    <img src="assets/images/avatar-1.jpg" width="64" height="64" loading="lazy" alt="Richard">
                  </a>
                </figure>

                <div>
                  <h3 class="card-title">
                    <a href="profile.html">@Shahrukh Khan</a>
                  </h3>

                  <data value="1.5">1.5 BNB</data>
                </div>

              </div>
            </li>

            <li>
              <div class="card top-seller-card">

                <figure class="card-avatar">
                  <a href="profile.html">
                    <img src="assets/images/avatar-2.jpg" width="64" height="64" loading="lazy" alt="John Deo">
                  </a>
                </figure>

                <div>
                  <h3 class="card-title">
                    <a href="profile.html">@Virat Kohli</a>
                  </h3>

                  <data value="2.3">2.3 BNB</data>
                </div>

              </div>
            </li>

            <li>
              <div class="card top-seller-card">

                <figure class="card-avatar">
                  <a href="profile.html">
                    <img src="./assets/images/avatar-3.jpg" width="64" height="64" loading="lazy" alt="Junaid">
                  </a>
                </figure>

                <div>
                  <h3 class="card-title">
                    <a href="profile.html">@Rajini Kanth</a>
                  </h3>

                  <data value="2.5">2.5 BNB</data>
                </div>

              </div>
            </li>

            <li>
              <div class="card top-seller-card">

                <figure class="card-avatar">
                  <a href="profile.html">
                    <img src="./assets/images/avatar-4.jpg" width="64" height="64" loading="lazy" alt="Yasmin">
                  </a>
                </figure>

                <div>
                  <h3 class="card-title">
                    <a href="profile.html">@Priyanka chopra</a>
                  </h3>

                  <data value="1.9">1.9 BNB</data>
                </div>

              </div>
            </li>

            <li>
              <div class="card top-seller-card">

                <figure class="card-avatar">
                  <a href="profile.html">
                    <img src="./assets/images/avatar-5.jpg" width="64" height="64" loading="lazy" alt="Arham H">
                  </a>
                </figure>

                <div>
                  <h3 class="card-title">
                    <a href="profile.html">@A-R rahman</a>
                  </h3>

                  <data value="3.2">3.2 BNB</data>
                </div>

              </div>
            </li>

            <li>
              <div class="card top-seller-card">

                <figure class="card-avatar">
                  <a href="profile.html">
                    <img src="./assets/images/avatar-6.jpg" width="64" height="64" loading="lazy" alt="Sara">
                  </a>
                </figure>

                <div>
                  <h3 class="card-title">
                    <a href="profile.html">@Ms_Dhoni</a>
                  </h3>

                  <data value="4.7">4.7 BNB</data>
                </div>

              </div>
            </li>

          </ul>

        </div>
      </section>

      <section class="section collection" id="collection">
        <div class="container">

          <p class="section-subtitle">Most Popular</p>

          <div class="title-wrapper">
            <h2 class="h2 section-title">Popular Collections</h2>

            <a href="#" class="btn-link">
              <span>View All</span>

              <ion-icon name="arrow-forward-outline" aria-hidden="true"></ion-icon>
            </a>
          </div>

          <ul class="grid-list">

            <li>
              <a href="#" class="card collection-card">

                <figure class="card-banner">
                  <img src="./assets/images/author-banner-1.jpg" width="600" height="450" loading="lazy"
                    alt="Virtual Worlds" class="img-cover">
                </figure>

                <figure class="card-avatar">
                  <img src="./assets/images/avatar-1.jpg" width="64" height="64" loading="lazy" alt="card avatar">
                </figure>

                <h3 class="h3 card-title">Virtual Worlds</h3>

                <span class="card-text">ERC-729</span>

              </a>
            </li>

            <li>
              <a href="#" class="card collection-card">

                <figure class="card-banner">
                  <img src="./assets/images/author-banner-2.jpg" width="600" height="450" loading="lazy"
                    alt="Digital Arts" class="img-cover">
                </figure>

                <figure class="card-avatar">
                  <img src="./assets/images/avatar-2.jpg" width="64" height="64" loading="lazy" alt="card avatar">
                </figure>

                <h3 class="h3 card-title">Digital Arts</h3>

                <span class="card-text">ERC-522</span>

              </a>
            </li>

            <li>
              <a href="#" class="card collection-card">

                <figure class="card-banner">
                  <img src="./assets/images/author-banner-3.jpg" width="600" height="450" loading="lazy" alt="Sports"
                    class="img-cover">
                </figure>

                <figure class="card-avatar">
                  <img src="./assets/images/avatar-3.jpg" width="64" height="64" loading="lazy" alt="card avatar">
                </figure>

                <h3 class="h3 card-title">Sports</h3>

                <span class="card-text">ERC-495</span>

              </a>
            </li>

            <li>
              <a href="#" class="card collection-card">

                <figure class="card-banner">
                  <img src="./assets/images/author-banner-4.jpg" width="600" height="450" loading="lazy"
                    alt="Photography" class="img-cover">
                </figure>

                <figure class="card-avatar">
                  <img src="./assets/images/avatar-4.jpg" width="64" height="64" loading="lazy" alt="card avatar">
                </figure>

                <h3 class="h3 card-title">Photography</h3>

                <span class="card-text">ERC-873</span>

              </a>
            </li>

            <li>
              <a href="#" class="card collection-card">

                <figure class="card-banner">
                  <img src="./assets/images/author-banner-5.jpg" width="600" height="450" loading="lazy"
                    alt="Collectibles" class="img-cover">
                </figure>

                <figure class="card-avatar">
                  <img src="./assets/images/avatar-5.jpg" width="64" height="64" loading="lazy" alt="card avatar">
                </figure>

                <h3 class="h3 card-title">Collectibles</h3>

                <span class="card-text">ERC-972</span>

              </a>
            </li>

            <li>
              <a href="#" class="card collection-card">

                <figure class="card-banner">
                  <img src="./assets/images/author-banner-6.jpg" width="600" height="450" loading="lazy"
                    alt="Trading Cards" class="img-cover">
                </figure>

                <figure class="card-avatar">
                  <img src="./assets/images/avatar-6.jpg" width="64" height="64" loading="lazy" alt="card avatar">
                </figure>

                <h3 class="h3 card-title">Trading Cards</h3>

                <span class="card-text">ERC-397</span>

              </a>
            </li>

            <li>
              <a href="#" class="card collection-card">

                <figure class="card-banner">
                  <img src="./assets/images/author-banner-7.jpg" width="600" height="450" loading="lazy"
                    alt="Walking On Air" class="img-cover">
                </figure>

                <figure class="card-avatar">
                  <img src="./assets/images/avatar-7.jpg" width="64" height="64" loading="lazy" alt="card avatar">
                </figure>

                <h3 class="h3 card-title">Walking On Air</h3>

                <span class="card-text">ERC-403</span>

              </a>
            </li>

            <li>
              <a href="#" class="card collection-card">

                <figure class="card-banner">
                  <img src="./assets/images/author-banner-8.jpg" width="600" height="450" loading="lazy"
                    alt="Domain Names" class="img-cover">
                </figure>

                <figure class="card-avatar">
                  <img src="./assets/images/avatar-8.jpg" width="64" height="64" loading="lazy" alt="card avatar">
                </figure>

                <h3 class="h3 card-title">Domain Names</h3>

                <span class="card-text">ERC-687</span>

              </a>
            </li>

          </ul>

        </div>
      </section>



    
  <footer class="footer">

    <div class="footer-top section">
      <div class="container">

        <div class="footer-brand">

          <a href="#" class="logo">
            <img src="assets/images/logo.png" width="50" height="50" alt=" home">
          </a>

          

        </div>

  </footer>




  <!-- 
    - #BACK TO TOP
  -->

  <a href="#top" class="back-to-top" aria-label="Back to Top" data-back-top-btn>
    <ion-icon name="arrow-up-outline"></ion-icon>
  </a>





  <!-- 
    - custom js link
  -->
  <script src="./assets/js/script.js"></script>

  <!-- 
    - ionicon link
  -->
  <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
  <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>

</body>

</html>

